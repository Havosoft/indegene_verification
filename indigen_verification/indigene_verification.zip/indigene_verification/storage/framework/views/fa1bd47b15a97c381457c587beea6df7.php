<p>Hello <?php echo e($user->name); ?>,</p>
<p>Thank you for registering on the Taraba State Indigene Verification Portal.</p>
<p>Your registration was successful. Please await verification by an administrator. You will be notified by email once you are verified.</p>
<p>Best regards,<br>Taraba State Indigene Verification Team</p> <?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/indigen_verification/indigene_verification/resources/views/emails/registration-success.blade.php ENDPATH**/ ?>