<?php $__env->startSection('title', 'Downloaded Certificates'); ?>
<?php $__env->startSection('header', 'Downloaded Certificates'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto py-10">
    <h1 class="text-2xl font-bold text-green-900 mb-6">Downloaded Certificates</h1>
    <div class="bg-white rounded shadow p-6">
        <table class="w-full min-w-[900px] text-left border-collapse">
            <thead>
                <tr class="bg-gray-100 text-gray-700 uppercase text-xs">
                    <th class="py-3 px-4">Certificate</th>
                    <th class="py-3 px-4 text-left">Price (₦)</th>
                    <th class="py-3 px-4">Payment Ref</th>
                    <th class="py-3 px-4">Date</th>
                    <th class="py-3 px-4">Preview</th>
                    <th class="py-3 px-4">Download</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $certificates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-b last:border-b-0">
                    <td class="py-3 px-4 font-medium text-gray-900"><?php echo e($cert->service_name); ?></td>
                    <td class="py-3 px-4 text-left text-gray-700">₦<?php echo e(number_format($cert->price)); ?></td>
                    <td class="py-3 px-4"><?php echo e($cert->payment_ref); ?></td>
                    <td class="py-3 px-4"><?php echo e($cert->created_at->format('Y-m-d H:i')); ?></td>
                    <td class="py-3 px-4 text-center">
                        <?php if($cert->approved && $cert->file): ?>
                            <?php $ext = strtolower(pathinfo($cert->file, PATHINFO_EXTENSION)); ?>
                            <?php if(in_array($ext, ['pdf'])): ?>
                                <a href="<?php echo e(route('certificates.download', $cert->id)); ?>" target="_blank" class="text-blue-700 underline">Preview</a>
                            <?php elseif(in_array($ext, ['jpg','jpeg','png','gif'])): ?>
                                <a href="<?php echo e(route('certificates.download', $cert->id)); ?>" target="_blank">
                                    <img src="<?php echo e(route('certificates.download', $cert->id)); ?>" alt="Preview" class="h-10 inline-block rounded shadow" />
                                </a>
                            <?php else: ?>
                                <span class="text-gray-400 text-xs">N/A</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="text-gray-400 text-xs">N/A</span>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 px-4 text-center">
                        <?php if($cert->approved && $cert->file): ?>
                            <a href="<?php echo e(route('certificates.download', $cert->id)); ?>" class="bg-green-700 text-white px-4 py-2 rounded hover:bg-green-800 transition">Download</a>
                        <?php elseif($cert->approved): ?>
                            <span class="text-yellow-600 text-xs">No file uploaded</span>
                        <?php else: ?>
                            <button class="bg-gray-300 text-gray-500 px-4 py-2 rounded cursor-not-allowed" disabled>Pending Approval</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="py-6 px-4 text-center text-gray-500">No certificates downloaded yet.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/indigen_verification/indigene_verification/resources/views/certificates/index.blade.php ENDPATH**/ ?>