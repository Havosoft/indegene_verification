<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NIN Verification Error Demo</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-8">
    <div class="max-w-4xl mx-auto">
        <h1 class="text-2xl font-bold text-gray-900 mb-6">NIN Verification Error Messages Demo</h1>
        
        <!-- Date of Birth Mismatch Error -->
        <div class="mb-8 p-4 bg-red-50 border-l-4 border-red-500 rounded-lg">
            <div class="flex items-start">
                <svg class="w-5 h-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <div class="text-red-800">
                    <h4 class="font-semibold mb-2">Verification Failed - Date of Birth Mismatch</h4>
                    <div class="text-sm leading-relaxed">
                        <?php echo nl2br(e("Your verification failed due to the following issues:

• Date of Birth mismatch: Your NIN shows '1962-05-27' but your registration shows '1990-01-15'. Please ensure your registration date matches your NIN record.

To resolve these issues:
• If your NIN information is incorrect, visit any NIMC enrollment center to update it
• If your registration information is incorrect, update your profile on this platform
• Contact support if you need assistance

Note: Only Taraba State indigenes with matching personal information are eligible for verification.")); ?>

                    </div>
                </div>
            </div>
        </div>

        <!-- Multiple Validation Errors -->
        <div class="mb-8 p-4 bg-red-50 border-l-4 border-red-500 rounded-lg">
            <div class="flex items-start">
                <svg class="w-5 h-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <div class="text-red-800">
                    <h4 class="font-semibold mb-2">Verification Failed - Multiple Issues</h4>
                    <div class="text-sm leading-relaxed">
                        <?php echo nl2br(e("Your verification failed due to the following issues:

• Your NIN record shows your State of Origin as Abuja — Gwagwalada LGA, not Taraba State. Only Taraba State indigenes are eligible.
• Date of Birth mismatch: Your NIN shows '1962-05-27' but your registration shows '1990-01-15'. Please ensure your registration date matches your NIN record.

To resolve these issues:
• If your NIN information is incorrect, visit any NIMC enrollment center to update it
• If your registration information is incorrect, update your profile on this platform
• Contact support if you need assistance

Note: Only Taraba State indigenes with matching personal information are eligible for verification.")); ?>

                    </div>
                </div>
            </div>
        </div>

        <!-- LGA Mismatch Error -->
        <div class="mb-8 p-4 bg-red-50 border-l-4 border-red-500 rounded-lg">
            <div class="flex items-start">
                <svg class="w-5 h-5 text-red-500 mt-0.5 mr-3 flex-shrink-0" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                    <path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
                <div class="text-red-800">
                    <h4 class="font-semibold mb-2">Verification Failed - LGA Mismatch</h4>
                    <div class="text-sm leading-relaxed">
                        <?php echo nl2br(e("Your verification failed due to the following issues:

• LGA mismatch: Your NIN shows 'Jalingo' but your registration shows 'Wukari'. Please ensure your registration LGA matches your NIN record.

To resolve these issues:
• If your NIN information is incorrect, visit any NIMC enrollment center to update it
• If your registration information is incorrect, update your profile on this platform
• Contact support if you need assistance

Note: Only Taraba State indigenes with matching personal information are eligible for verification.")); ?>

                    </div>
                </div>
            </div>
        </div>

        <div class="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h3 class="font-semibold text-blue-900 mb-2">How the Enhanced Verification Works:</h3>
            <ul class="text-sm text-blue-800 space-y-1">
                <li><strong>1. State Validation:</strong> Must be from Taraba State</li>
                <li><strong>2. LGA Matching:</strong> Registration LGA must match NIN LGA</li>
                <li><strong>3. Date of Birth:</strong> Registration date must exactly match NIN date</li>
                <li><strong>4. Detailed Errors:</strong> Specific messages for each validation failure</li>
                <li><strong>5. Clear Guidance:</strong> Step-by-step instructions to resolve issues</li>
            </ul>
        </div>
    </div>
</body>
</html><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/indigen_verification/indigene_verification/resources/views/test-error.blade.php ENDPATH**/ ?>