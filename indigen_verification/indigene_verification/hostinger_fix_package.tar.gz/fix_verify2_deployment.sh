#!/bin/bash

# =============================================================================
# Hostinger Laravel Deployment Fix Script - verify2 Directory
# =============================================================================
# This script fixes the missing vendor/autoload.php issue in your Laravel app
# deployed at: /home/u681625981/domains/collaboratoor.com/public_html/verify2/
# =============================================================================

set -e  # Exit on any error

echo "🚀 Starting Laravel Deployment Fix for verify2..."
echo "================================================="

# Define paths
APP_PATH="/home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification"
PUBLIC_PATH="$APP_PATH/public"
STORAGE_PATH="$APP_PATH/storage"
BOOTSTRAP_CACHE="$APP_PATH/bootstrap/cache"

# Function to print colored output
print_status() {
    echo "✅ $1"
}

print_error() {
    echo "❌ $1"
}

print_info() {
    echo "ℹ️  $1"
}

# Check if we're in the right directory
echo "🔍 Checking deployment location..."
if [ ! -d "$APP_PATH" ]; then
    print_error "Laravel app directory not found at: $APP_PATH"
    echo "Please ensure your Laravel app is uploaded to the correct location."
    exit 1
fi

cd "$APP_PATH"
print_status "Found Laravel app at: $(pwd)"

# Check for composer.json
if [ ! -f "composer.json" ]; then
    print_error "composer.json not found. This doesn't appear to be a Laravel project."
    exit 1
fi
print_status "composer.json found"

# Check PHP version
echo "🐘 Checking PHP version..."
PHP_VERSION=$(php -v | head -n 1)
print_info "$PHP_VERSION"

# Check if Composer is available
echo "📦 Checking Composer availability..."
if ! command -v composer &> /dev/null; then
    print_error "Composer not found. Please install Composer or contact Hostinger support."
    echo "You can try: curl -sS https://getcomposer.org/installer | php"
    echo "Then: php composer.phar install --optimize-autoloader --no-dev"
    exit 1
fi
print_status "Composer is available"

# Install/Update vendor dependencies
echo "📚 Installing Composer dependencies..."
if [ ! -d "vendor" ]; then
    print_info "vendor directory not found. Installing dependencies..."
    composer install --optimize-autoloader --no-dev --no-interaction
else
    print_info "vendor directory exists. Updating dependencies..."
    composer install --optimize-autoloader --no-dev --no-interaction
fi

# Verify autoload.php exists
if [ ! -f "vendor/autoload.php" ]; then
    print_error "vendor/autoload.php still missing after Composer install"
    echo "Trying to regenerate autoload files..."
    composer dump-autoload --optimize --no-dev
    
    if [ ! -f "vendor/autoload.php" ]; then
        print_error "Failed to create vendor/autoload.php"
        echo "Please check Composer installation and try manually:"
        echo "composer install --optimize-autoloader --no-dev"
        exit 1
    fi
fi
print_status "vendor/autoload.php is now available"

# Set up environment file
echo "⚙️  Setting up environment configuration..."
if [ ! -f ".env" ]; then
    if [ -f ".env.production" ]; then
        cp .env.production .env
        print_status ".env created from .env.production template"
    elif [ -f ".env.example" ]; then
        cp .env.example .env
        print_status ".env created from .env.example template"
    else
        print_error "No .env template found. Please create .env manually."
        echo "Required .env variables:"
        echo "APP_NAME, APP_ENV=production, APP_DEBUG=false, APP_URL"
        echo "DB_CONNECTION, DB_HOST, DB_DATABASE, DB_USERNAME, DB_PASSWORD"
        exit 1
    fi
else
    print_status ".env file already exists"
fi

# Create necessary directories
echo "📁 Creating necessary directories..."
mkdir -p "$STORAGE_PATH/app/public"
mkdir -p "$STORAGE_PATH/framework/cache"
mkdir -p "$STORAGE_PATH/framework/sessions"
mkdir -p "$STORAGE_PATH/framework/views"
mkdir -p "$STORAGE_PATH/logs"
mkdir -p "$BOOTSTRAP_CACHE"
print_status "Directories created"

# Set proper permissions
echo "🔐 Setting file permissions..."
chmod -R 755 "$STORAGE_PATH"
chmod -R 755 "$BOOTSTRAP_CACHE"
chmod -R 755 "$PUBLIC_PATH"
chmod 644 .env 2>/dev/null || true
print_status "Permissions set"

# Generate application key if missing
echo "🔑 Checking application key..."
if ! grep -q "APP_KEY=base64:" .env 2>/dev/null; then
    print_info "Generating application key..."
    php artisan key:generate --force
    print_status "Application key generated"
else
    print_status "Application key already exists"
fi

# Clear all caches
echo "🧹 Clearing caches..."
php artisan config:clear 2>/dev/null || true
php artisan cache:clear 2>/dev/null || true
php artisan view:clear 2>/dev/null || true
php artisan route:clear 2>/dev/null || true
print_status "Caches cleared"

# Test database connection before migrations
echo "🗄️  Testing database connection..."
if php artisan migrate:status &>/dev/null; then
    print_status "Database connection successful"
    
    echo "📊 Running database migrations..."
    php artisan migrate --force
    print_status "Database migrations completed"
else
    print_error "Database connection failed"
    echo "Please check your .env database settings:"
    echo "DB_HOST, DB_DATABASE, DB_USERNAME, DB_PASSWORD"
    echo "You can continue without migrations for now."
fi

# Create storage link
echo "🔗 Creating storage link..."
if [ ! -L "$PUBLIC_PATH/storage" ]; then
    php artisan storage:link
    print_status "Storage link created"
else
    print_status "Storage link already exists"
fi

# Optimize for production
echo "⚡ Optimizing for production..."
php artisan config:cache
php artisan route:cache 2>/dev/null || true
php artisan view:cache
print_status "Production optimization completed"

# Final verification
echo "🔍 Final verification..."
if [ -f "vendor/autoload.php" ]; then
    print_status "vendor/autoload.php exists"
else
    print_error "vendor/autoload.php still missing!"
fi

if [ -f ".env" ]; then
    print_status ".env file exists"
else
    print_error ".env file missing!"
fi

if [ -d "$STORAGE_PATH" ] && [ -w "$STORAGE_PATH" ]; then
    print_status "Storage directory is writable"
else
    print_error "Storage directory issues detected"
fi

echo ""
echo "🎉 Deployment fix completed!"
echo "================================================="
echo "Your Laravel application should now be accessible at:"
echo "🌐 https://collaboratoor.com/verify2/"
echo ""
echo "📋 Next steps:"
echo "1. Test your website in a browser"
echo "2. Check error logs: tail -f storage/logs/laravel.log"
echo "3. Update .env with your production settings:"
echo "   - Database credentials"
echo "   - Mail settings"
echo "   - Paystack API keys"
echo "   - APP_URL=https://collaboratoor.com/verify2"
echo ""
echo "🔧 If you encounter issues:"
echo "1. Check file permissions: ls -la storage/ bootstrap/cache/"
echo "2. Verify PHP version: php -v (should be 8.1+)"
echo "3. Check error logs: tail -f storage/logs/laravel.log"
echo "4. Test database: php artisan migrate:status"
echo ""
echo "✅ Deployment fix script completed successfully!"