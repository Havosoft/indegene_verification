# 🚨 Hostinger Deployment Fix - verify2 Directory

## Current Issue Analysis
**Error Location**: `/home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification/public/index.php`
**Missing File**: `vendor/autoload.php`

The Laravel application is deployed in the `verify2` directory but the `vendor/` folder is missing.

## 🔧 Immediate Fix Solutions

### **Solution 1: Upload Missing vendor Directory (Fastest)**

1. **Compress your local vendor directory**:
   ```bash
   cd /Applications/XAMPP/xamppfiles/htdocs/indigen_verification/indigene_verification
   tar -czf vendor.tar.gz vendor/
   ```

2. **Upload vendor.tar.gz to Hostinger**:
   - Upload to: `/home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification/`
   - Extract: `tar -xzf vendor.tar.gz`

### **Solution 2: Run Composer Install on Server**

SSH into your Hostinger account:
```bash
cd /home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification/
composer install --optimize-autoloader --no-dev
```

### **Solution 3: Complete Re-deployment**

1. **Delete current verify2 folder**
2. **Upload the deployment package** (`indigene_verification_deploy.tar.gz`)
3. **Extract to**: `/home/u681625981/domains/collaboratoor.com/public_html/verify2/`

## 📋 Required File Structure

Your server should have this structure:
```
/home/u681625981/domains/collaboratoor.com/public_html/verify2/
├── indigene_verification/           # Laravel application root
│   ├── vendor/                      # ← THIS IS MISSING!
│   │   └── autoload.php            # ← Required file
│   ├── app/
│   ├── bootstrap/
│   ├── config/
│   ├── database/
│   ├── resources/
│   ├── routes/
│   ├── storage/
│   ├── .env                        # Production environment
│   ├── artisan
│   └── composer.json
│   └── public/                     # Web document root
│       ├── index.php              # Entry point
│       ├── .htaccess
│       └── build/                 # Compiled assets
```

## 🔍 Diagnostic Commands

Run these via SSH to check your deployment:

```bash
# Navigate to your Laravel app
cd /home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification/

# Check if vendor exists
ls -la vendor/

# Check if autoload.php exists
ls -la vendor/autoload.php

# Check if composer.json exists
ls -la composer.json

# Check PHP version
php -v

# Check current directory structure
ls -la
```

## ⚡ Quick Fix Script

Create this script on your server:

```bash
#!/bin/bash
# Save as fix_verify2.sh

echo "🔧 Fixing Laravel deployment in verify2..."

cd /home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification/

# Check if we're in the right place
if [ ! -f "composer.json" ]; then
    echo "❌ Error: Not in Laravel root directory"
    echo "Current location: $(pwd)"
    exit 1
fi

# Install vendor dependencies
if [ ! -d "vendor" ]; then
    echo "📦 Installing Composer dependencies..."
    composer install --optimize-autoloader --no-dev
else
    echo "✅ vendor directory exists"
fi

# Check if autoload.php exists
if [ -f "vendor/autoload.php" ]; then
    echo "✅ vendor/autoload.php found"
else
    echo "❌ vendor/autoload.php still missing"
    echo "Try: composer dump-autoload"
    composer dump-autoload --optimize
fi

# Set up environment
if [ ! -f ".env" ]; then
    if [ -f ".env.production" ]; then
        cp .env.production .env
        echo "✅ .env created from template"
    else
        echo "❌ No .env file found - create manually"
    fi
fi

# Set permissions
chmod -R 755 storage/ bootstrap/cache/ public/
chmod 644 .env

# Generate app key if needed
if ! grep -q "APP_KEY=base64:" .env; then
    php artisan key:generate --force
fi

# Clear caches
php artisan config:clear
php artisan cache:clear
php artisan view:clear
php artisan route:clear

# Optimize for production
php artisan config:cache
php artisan route:cache
php artisan view:cache

echo "🎉 Fix completed!"
echo "Test your site: https://collaboratoor.com/verify2/"
```

## 🚀 Step-by-Step Fix Process

### **Step 1: Access Your Server**
- SSH into Hostinger
- Or use File Manager with terminal

### **Step 2: Navigate to Project**
```bash
cd /home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification/
```

### **Step 3: Install Dependencies**
```bash
composer install --optimize-autoloader --no-dev
```

### **Step 4: Configure Environment**
```bash
# Copy environment file
cp .env.production .env

# Edit .env with your production settings
nano .env
```

### **Step 5: Set Permissions**
```bash
chmod -R 755 storage/ bootstrap/cache/ public/
chmod 644 .env
```

### **Step 6: Run Laravel Setup**
```bash
php artisan key:generate --force
php artisan migrate --force
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## 📝 Environment Configuration

Update your `.env` file with:

```env
APP_NAME="Taraba State Indigene Verification Portal"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://collaboratoor.com/verify2

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=your_hostinger_database
DB_USERNAME=your_hostinger_user
DB_PASSWORD=your_hostinger_password

MAIL_MAILER=smtp
MAIL_HOST=smtp.hostinger.com
MAIL_PORT=587
MAIL_USERNAME=your_email@collaboratoor.com
MAIL_PASSWORD=your_email_password
MAIL_ENCRYPTION=tls

PAYSTACK_PUBLIC_KEY=pk_live_your_live_key
PAYSTACK_SECRET_KEY=sk_live_your_live_key
```

## 🔧 Alternative: Domain Configuration

If you want the app to be accessible directly (without /verify2):

1. **Point your domain** to: `/home/u681625981/domains/collaboratoor.com/public_html/verify2/indigene_verification/public/`
2. **Update APP_URL** in .env: `APP_URL=https://collaboratoor.com`

## ✅ Verification Steps

After fixing:

1. **Check vendor exists**: `ls -la vendor/autoload.php`
2. **Test website**: Visit your domain
3. **Check logs**: `tail -f storage/logs/laravel.log`
4. **Test features**: Registration, login, payment

## 📞 Need Help?

- **Check error logs**: `tail -f storage/logs/laravel.log`
- **Verify PHP version**: Should be 8.1+
- **Contact Hostinger support** for server-specific issues
- **Check file permissions**: `ls -la storage/ bootstrap/cache/`

---

**The main issue is the missing `vendor/` directory. Follow Solution 1 or 2 above to resolve it quickly.**